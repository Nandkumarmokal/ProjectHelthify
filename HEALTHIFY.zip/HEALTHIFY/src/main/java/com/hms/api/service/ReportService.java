package com.hms.api.service;

public interface ReportService {

}
